package com.alireza.freewarp

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.Chronometer
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.children
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.crypto.KeyPair
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private enum class Ui { OFF, CONNECTING, ON }

    private lateinit var backend: GoBackend
    private val tunnel = AppTunnel()

    private lateinit var powerButton: FrameLayout
    private lateinit var powerIcon: ImageView
    private lateinit var pulse: View
    private lateinit var statusDot: View
    private lateinit var statusTitle: TextView
    private lateinit var statusSub: TextView
    private lateinit var timer: Chronometer
    private lateinit var endpointBox: EditText
    private lateinit var chips: LinearLayout

    private var pulseAnim: ValueAnimator? = null
    private var busy = false

    private val prefs by lazy { getSharedPreferences("freewarp", Context.MODE_PRIVATE) }

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) startFreeVpn()
            else toast(getString(R.string.vpn_permission_denied))
        }

    inner class AppTunnel : Tunnel {
        override fun getName(): String = "freewarp"
        override fun onStateChange(newState: Tunnel.State) {
            runOnUiThread { if (!busy) render(newState) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        backend = GoBackend(applicationContext)

        powerButton = findViewById(R.id.powerButton)
        powerIcon = findViewById(R.id.powerIcon)
        pulse = findViewById(R.id.pulse)
        statusDot = findViewById(R.id.statusDot)
        statusTitle = findViewById(R.id.statusTitle)
        statusSub = findViewById(R.id.statusSub)
        timer = findViewById(R.id.timer)
        endpointBox = findViewById(R.id.endpointBox)
        chips = findViewById(R.id.chips)

        endpointBox.setText(prefs.getString("endpoint", DEFAULT_ENDPOINT))
        syncChips(endpointBox.text.toString().trim())
        endpointBox.addTextChangedListener(afterTextChanged = { e ->
            syncChips(e?.toString().orEmpty().trim())
        })

        chips.children.forEach { chip ->
            chip.setOnClickListener {
                if (endpointBox.isEnabled) endpointBox.setText(it.tag.toString())
            }
        }

        powerButton.setOnClickListener { v ->
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).withEndAction {
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }.start()

            if (busy) return@setOnClickListener
            if (backend.getState(tunnel) == Tunnel.State.UP) {
                disconnect()
            } else {
                val intent = VpnService.prepare(this)
                if (intent != null) vpnPermission.launch(intent) else startFreeVpn()
            }
        }

        render(backend.getState(tunnel))
    }

    override fun onDestroy() {
        stopPulse()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ VPN

    private fun startFreeVpn() {
        val ep = endpointBox.text.toString().trim().ifEmpty { DEFAULT_ENDPOINT }
        prefs.edit().putString("endpoint", ep).apply()
        busy = true
        applyUi(Ui.CONNECTING)

        lifecycleScope.launch {
            try {
                val confText = withContext(Dispatchers.IO) { getOrRegisterWarpConfig(ep) }
                val config = withContext(Dispatchers.IO) {
                    Config.parse(confText.byteInputStream())
                }
                val s = withContext(Dispatchers.IO) {
                    backend.setState(tunnel, Tunnel.State.UP, config)
                }
                busy = false
                render(s)
            } catch (e: Exception) {
                busy = false
                toast("خطا در اتصال: ${e.message}")
                applyUi(Ui.OFF, getString(R.string.hint_error))
            }
        }
    }

    private fun getOrRegisterWarpConfig(endpoint: String): String {
        var privKey = prefs.getString("priv_key", null)
        var v4 = prefs.getString("v4", null)
        var v6 = prefs.getString("v6", null)

        if (privKey == null || v4 == null) {
            val kp = KeyPair()
            privKey = kp.privateKey.toBase64()
            val pubKey = kp.publicKey.toBase64()

            val conn = (URL("https://api.cloudflareclient.com/v0a2158/reg")
                .openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "okhttp/3.12.1")
                setRequestProperty("CF-Client-Version", "a-6.3-1922")
                connectTimeout = 15000
                readTimeout = 15000
            }

            val tos = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(Date())
            val payload = JSONObject().apply {
                put("key", pubKey)
                put("install_id", "")
                put("fcm_token", "")
                put("tos", tos)
                put("type", "Android")
                put("model", "PC")
                put("locale", "en_US")
            }

            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

            val code = conn.responseCode
            if (code !in 200..299) {
                throw IOException("پاسخ سرور کلودفلر: HTTP $code")
            }
            val resp = conn.inputStream.bufferedReader().use { it.readText() }
            val addresses = JSONObject(resp)
                .getJSONObject("config")
                .getJSONObject("interface")
                .getJSONObject("addresses")

            v4 = addresses.getString("v4")
            v6 = addresses.optString("v6", "").ifEmpty { null }

            prefs.edit()
                .putString("priv_key", privKey)
                .putString("v4", v4)
                .putString("v6", v6)
                .apply()
        }

        val address = if (v6 != null) "$v4/32, $v6/128" else "$v4/32"
        val allowed = if (v6 != null) "0.0.0.0/0, ::/0" else "0.0.0.0/0"

        return listOf(
            "[Interface]",
            "PrivateKey = $privKey",
            "Address = $address",
            "DNS = 1.1.1.1, 1.0.0.1",
            "MTU = 1280",
            "",
            "[Peer]",
            "PublicKey = $WARP_PUBLIC_KEY",
            "AllowedIPs = $allowed",
            "Endpoint = $endpoint",
            "PersistentKeepalive = 25"
        ).joinToString("\n")
    }

    private fun disconnect() {
        busy = true
        lifecycleScope.launch {
            try {
                val s = withContext(Dispatchers.IO) {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                }
                busy = false
                render(s)
            } catch (e: Exception) {
                busy = false
                toast("خطا در قطع اتصال: ${e.message}")
            }
        }
    }

    // ------------------------------------------------------------------ UI

    private fun render(state: Tunnel.State) {
        applyUi(if (state == Tunnel.State.UP) Ui.ON else Ui.OFF)
    }

    private fun applyUi(ui: Ui, sub: String? = null) {
        val dotColor: Int
        when (ui) {
            Ui.OFF -> {
                dotColor = R.color.idle
                powerButton.setBackgroundResource(R.drawable.bg_power_off)
                powerIcon.setColorFilter(color(R.color.text_secondary))
                statusTitle.setText(R.string.status_off)
                statusSub.text = sub ?: getString(R.string.hint_off)
                stopPulse()
                stopTimer()
            }
            Ui.CONNECTING -> {
                dotColor = R.color.warn
                powerButton.setBackgroundResource(R.drawable.bg_power_connecting)
                powerIcon.setColorFilter(color(R.color.on_warn))
                statusTitle.setText(R.string.status_connecting)
                statusSub.text = sub ?: getString(R.string.hint_connecting)
                startPulse(R.drawable.bg_ring_connecting, 1100L)
                stopTimer()
            }
            Ui.ON -> {
                dotColor = R.color.accent
                powerButton.setBackgroundResource(R.drawable.bg_power_on)
                powerIcon.setColorFilter(color(R.color.on_accent))
                statusTitle.setText(R.string.status_on)
                statusSub.text = sub ?: getString(R.string.hint_on)
                startPulse(R.drawable.bg_ring_on, 2200L)
                startTimer()
            }
        }
        (statusDot.background.mutate() as GradientDrawable).setColor(color(dotColor))

        val editable = ui == Ui.OFF
        endpointBox.isEnabled = editable
        endpointBox.alpha = if (editable) 1f else 0.5f
        chips.children.forEach {
            it.isEnabled = editable
            it.alpha = if (editable) 1f else 0.5f
        }
    }

    private fun syncChips(current: String) {
        chips.children.forEach { it.isSelected = it.tag?.toString() == current }
    }

    private fun startPulse(ringRes: Int, durationMs: Long) {
        stopPulse()
        pulse.setBackgroundResource(ringRes)
        pulse.visibility = View.VISIBLE
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                pulse.scaleX = 1f + 0.32f * f
                pulse.scaleY = 1f + 0.32f * f
                pulse.alpha = 0.7f * (1f - f)
            }
            start()
        }
    }

    private fun stopPulse() {
        pulseAnim?.cancel()
        pulseAnim = null
        pulse.visibility = View.INVISIBLE
    }

    private fun startTimer() {
        var since = prefs.getLong("connected_at", 0L)
        if (since == 0L) {
            since = System.currentTimeMillis()
            prefs.edit().putLong("connected_at", since).apply()
        }
        timer.base = SystemClock.elapsedRealtime() - (System.currentTimeMillis() - since)
        timer.visibility = View.VISIBLE
        timer.start()
    }

    private fun stopTimer() {
        timer.stop()
        timer.visibility = View.INVISIBLE
        prefs.edit().remove("connected_at").apply()
    }

    private fun color(res: Int) = ContextCompat.getColor(this, res)

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    companion object {
        private const val DEFAULT_ENDPOINT = "162.159.192.1:2408"
        private const val WARP_PUBLIC_KEY = "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo="
    }
}
